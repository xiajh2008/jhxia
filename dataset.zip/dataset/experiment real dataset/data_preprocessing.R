data<-read.csv('HTRU_2.csv', header = FALSE)
write.table(data, file = 'htru.txt', sep = ' ', row.names = FALSE, col.names = FALSE)

