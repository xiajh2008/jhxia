setwd('/home/jhxia/dataset/experiment synthetic dataset')
# setwd('/home/jhxia/dataset/experiment real dataset')

# read data from txt-------------------------------------------

  ss='Aggregation.txt'
  # ss='CMC_new.txt'
  # ss='Compound.txt'
  # ss='D31.txt'
  # ss='flame.txt'
  # ss='jain.txt'
  # ss='pathbased.txt'
  # ss='R15.txt'
  # ss='spiral.txt'
  # ss='dim256_new.txt'

  # output into txt-----------------------------------------------
  
  # tt="RNN_DBSCAN_synthetic_result/result_Aggregation.txt"
  # tt="RNN_DBSCAN_synthetic_result/result_CMC.txt"
  # tt="RNN_DBSCAN_synthetic_result/result_Compound.txt"
  # tt="RNN_DBSCAN_synthetic_result/result_D31.txt"
  # tt="RNN_DBSCAN_synthetic_result/result_flame.txt"
  # tt="RNN_DBSCAN_synthetic_result/result_jain.txt"
  # tt="RNN_DBSCAN_synthetic_result/result_pathbased.txt"
  # tt="RNN_DBSCAN_synthetic_result/result_R15.txt"
  # tt="RNN_DBSCAN_synthetic_result/result_spiral.txt"
  
  # ss='ecoli.data'
  # ss='iris.txt'
  # ss='seeds.txt'
  # ss='movement_libras.data'
  # ss='segmentation2.data'
  # ss='ionosphere.data'
  # ss='banknote_authentication.txt'
  # ss='wine.data'
  # ss='wdbc.data'
  # ss='optdigits.tes'
  # ss = 'HTRU_2.csv'
  
      t=7
      # data = read.csv(ss, header = FALSE)
      data = read.csv(ss, header = FALSE, sep = '\t')
      # data<- read.table(ss,sep = ',',header = FALSE)
      a=dim(data)
        
      clustering <- rnndbscan::rnndbscan(data[,1:a[2]-1],t)
      ari <- rnndbscan::ari(clustering,data[,a[2]])
      ari
  # clustering <- rnndbscan::rnndbscan(data[,2:a[2]],t)  #*****************if class label locate in dimension 1**********************
  # clustering <- rnndbscan::rnndbscan(data[,3:a[2]],t)  ##################################wdbc#################################
  # data[,a[2]]
  # clustering
  write.table(data[,a[2]], 'perf_index/truth.txt', sep = ' ', row.names = FALSE, col.names = FALSE)
  # write.table(data[,1], 'perf_index/truth.txt', sep = ' ', row.names = FALSE, col.names = FALSE)#*****************if class label locate in dimension 1**********************
  # write.table(data[,2], 'perf_index/truth.txt', sep = ' ', row.names = FALSE, col.names = FALSE)  ############################### ###wdbc#################################
  write.table(clustering, 'perf_index/predict.txt', sep = ' ', row.names = FALSE, col.names = FALSE)
  # plot(data[,1:2],col=clustering+2,xlab="dim 1",ylab="dim 2")
  # write.table(clustering+2, tt, sep = ' ', row.names = FALSE, col.names = FALSE) # output result into txt
  temp=cbind(data[,1:a[2]-1], data[,a[2]], clustering)
  write.table(temp, tt, sep = ' ', row.names = FALSE, col.names = FALSE) # output result into txt
  
  L <- dbscan::nnlist(data[,1:a[2]-1],t)  # adjust data features
  # L <- rnndbscan::nnlist(data[,2:a[2]],t)  # #*****************if class label locate in dimension 1**********************
  # L <- rnndbscan::nnlist(data[,3:a[2]],t)  ##################################wdbc#################################
  # run rnndbscan for k = 1..10------------------------------------------------------
  clusterings <- matrix(nrow=t,ncol=L$n)
  for(k in 1:t){
    clusterings[k,] <- rnndbscan::rnndbscanlist(L,k)
  }
  # compute ari of the clustering solutions using class labels-----------------------
  aris <- rnndbscan::ari(clusterings,data[,a[2]])
  # aris <- rnndbscan::ari(clusterings,data[,1])  #*****************if class label locate in dimension 1**********************
  # aris <- rnndbscan::ari(clusterings,data[,2])  ##################################wdbc#################################
    # create plot of ari performance over k--------------------------------------------
  plot(aris,xlab="k",ylab="ari")
  aris
